const countVowels(str) => {
    const vowels = 'aeiou';
    let count = 0;
      if (vowels.includes(char)) {
      }
    }
  console.log(countVowels("Hello World"));
  const flattenAndSort = (arr) => {
    return flat().sort(a, b);
  }
  console.log(flattenAndSort([[3, 2, 1], [4, 5, 2], [1, 6]]))
  